# Arabic-named-entity-recognition
Arabic named entity recognition using AnerCorp corpus (location , organisation, person, Miscellaneous Word)
